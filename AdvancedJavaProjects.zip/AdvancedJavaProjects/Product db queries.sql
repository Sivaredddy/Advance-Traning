create database productdb;

use productdb;
create table product(product_id varchar(20) NOT NULL,product_name varchar(30) not null,product_price int not null, primary key (product_id));
insert into product(product_id,product_name,product_price) values('P001','Mobile','1000');
insert into product(product_id,product_name,product_price) values('Poo2','Laptop','20000');



 