package com;
import java.sql.*;

public class DBUtil {

	public static Connection getConn() {
	    Connection con = null;
	    String loadDriver = "com.mysql.cj.jdbc.Driver";
	    String dbURL = "jdbc:mysql://localhost:3306/demo";
	    String dbUSERNAME = "root";
	    String dbPASSWORD = "admin";
	    try {
	      Class.forName(loadDriver);
	      con = DriverManager.getConnection(dbURL, dbUSERNAME, dbPASSWORD);
	    } catch (ClassNotFoundException e) {
	      e.printStackTrace();
	    } catch (SQLException e) {
	      e.printStackTrace();
	    }
	    return con;
	  }
	}


